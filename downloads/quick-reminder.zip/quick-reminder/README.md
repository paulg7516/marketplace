# Quick Reminder

A Chrome extension for the things that cross your mind between tasks. Type a
note, say when, forget it, get a desktop notification.

Think -> capture -> set when -> forget -> get reminded.

It deliberately does not become a task manager. No projects, no tags, no
boards, no settings.

## Install

1. Open `chrome://extensions`
2. Turn on **Developer mode** (top right)
3. Click **Load unpacked** and pick this folder
4. Pin the extension so the icon stays in the toolbar

## Using it

Click the toolbar icon or press the keyboard shortcut. The note field is
already focused, so you can start typing immediately.

- **Enter** saves. **Shift+Enter** adds a line break. **Esc** closes.
- Pick a time with one of the quick pills, or just type it into the note.
- Hovering a row reveals a check (done) and an x (delete).
- **Click a row to open it.** The full note loads back into the field, so a long
  one is readable in full, and its exact time appears in the picker. Change
  either and press Update, or press Cancel or Escape to back out - nothing is
  written until you update. Giving it a future time re-arms one that had already
  fired.

The note field grows as you type so a long message stays fully visible, up to
220px, after which it scrolls. You can also drag the grip in its bottom-right
corner to size it yourself; once you do, it stops resizing itself for the rest
of that popup session. The Upcoming list gives up height to make room, so the
window never exceeds Chrome's 600px popup ceiling.

### Typing the time into the note

The time phrase is pulled out of the sentence and removed from the saved note,
so you write the way you would to yourself:

| You type | Saved as | Reminds you |
| --- | --- | --- |
| `Follow up with Sarah friday 2pm` | Follow up with Sarah | Friday, 2:00 PM |
| `call Bob tomorrow 9am` | call Bob | Tomorrow, 9:00 AM |
| `ping ops at 3` | ping ops | Today, 3:00 PM |
| `review the doc tonight` | review the doc | Today, 7:00 PM |
| `renew cert sep 22` | renew cert | Sep 22, 9:00 AM |
| `call the vendor in 2 hours` | call the vendor | two hours from now |
| `standup tomorrow morning` | standup | Tomorrow, 9:00 AM |

What it understands: `in N minutes/hours/days/weeks`, `today`, `tonight`,
`tomorrow`, `day after tomorrow`, `next week`, weekday names, `Sep 22`,
clock times (`2pm`, `14:30`, `at 3`), and `morning` / `afternoon` /
`evening` / `noon` / `midnight`.

A bare number only counts as a time when it carries `am`/`pm`, a colon, or the
word `at` in front of it, so "buy 4 licenses" is not read as 4 o'clock. An hour
with no meridiem between 1 and 7 is read as afternoon, so "at 3" means 3 PM and
"at 9" means 9 AM.

Picking a pill overrides a time you typed, but the phrase is still stripped out
of the note - it was meant as a time either way.

## The keyboard shortcut

The default is **Cmd+Shift+E** on macOS and **Ctrl+Shift+E** elsewhere.

Click the shortcut pill in the popup header to change it - it opens
`chrome://extensions/shortcuts`. The pill always shows the binding Chrome
actually has, and reads "Set shortcut" when there is none.

Two shortcuts that look available but are not:

- **Cmd+Shift+R**, from the original concept, is reserved by Chrome for hard
  reload and cannot be taken by an extension.
- **Cmd+Shift+Y** is claimed by the macOS "Make New Sticky Note" service, which
  swallows the keystroke before Chrome sees it. Chrome will happily show the
  binding as assigned while nothing happens when you press it. If you want that
  combination back, turn the service off under System Settings > Keyboard >
  Keyboard Shortcuts > Services > Text.

Chrome only applies a manifest's suggested key at install time. If you had an
earlier version loaded, reloading will not move the binding - set it yourself at
`chrome://extensions/shortcuts`.

## Notifications

At the scheduled time you get a desktop notification with the note and two
buttons:

- **Done** clears the reminder
- **Snooze 10 min** pushes it out and reschedules

Clicking the notification body reopens the popup. Chrome allows a maximum of
two notification buttons, which is why the concept's third action lives on the
body click rather than a third button.

A reminder fires **once**. After that it is marked as fired and moves to a
**Waiting on you** group at the top of the list, in amber, showing how long it
has been sitting there. It stays there until you hit Done or delete it, and it
will not go off again - not when you save another reminder, and not when Chrome
restarts. Snoozing clears the fired mark and puts it back in the queue.

So dismissing a notification does not complete the reminder; it just stops the
banner. The item is still in the popup waiting for a decision.

If more than three reminders came due while the browser was closed, you get one
summary notification instead of a pile of them.

The toolbar badge counts only what is **waiting on you** - reminders that have
fired and not been cleared. Something scheduled for next Tuesday shows no badge,
because that is exactly what you handed over in order to stop thinking about it.
The badge appears when a reminder goes off and clears when you hit Done.

## If a reminder never fires

Work down this list; the first two account for almost everything.

1. **macOS is suppressing it.** System Settings > Notifications > Google Chrome
   must have Allow Notifications on, with the style set to **Alerts**. Also
   check that Do Not Disturb or a Focus mode is not active - a Focus will
   swallow the notification without any error anywhere.
2. **Chrome has to be running** at the scheduled time. If it is closed, the
   reminder fires when Chrome next starts.
3. **Look at the service worker log.** `chrome://extensions` > Quick Reminder >
   click **service worker**. Failures are logged there with a
   `Quick Reminder:` prefix.
4. **Check the alarm exists.** In that same console:

   ```js
   chrome.alarms.getAll().then(a => console.table(
     a.map(x => ({ name: x.name, fires: new Date(x.scheduledTime).toLocaleString() }))
   ));
   ```

   Every pending reminder should have a row. If one is missing, open and close
   the popup - the service worker reconciles alarms against storage on every
   change.
5. **Test the notification path directly**, same console:

   ```js
   chrome.notifications.create({ type: 'basic', iconUrl: 'icons/icon128.png',
     title: 'Test', message: 'If you can see this, notifications work.' });
   ```

   If this shows nothing, the problem is step 1, not the extension.

The popup also shows a red bar when Chrome itself has notifications blocked,
rather than letting you file reminders that can never fire.

## Platform constraints worth knowing

- **macOS notifications.** When Chrome uses the native macOS notification
  centre, buttons appear behind the notification's Options affordance rather
  than inline, and `requireInteraction` is ignored - macOS decides how long a
  banner stays. Both are OS behaviour, not something the extension controls.
- **Alarm granularity.** Chrome clamps extension alarms to a 30 second minimum,
  so a custom time a few seconds out fires at about 30 seconds.
- **Reopening the popup** from a notification click needs Chrome 127 or newer.
  On older versions the click dismisses the notification and the badge still
  shows what is pending.
- **Accuracy.** Reminders fire while Chrome is running. If Chrome is closed at
  the scheduled time, the reminder fires when it next starts.

## Files

```
manifest.json    MV3 manifest: storage, alarms, notifications. No host permissions.
popup.html/css   The capture surface. Light and dark follow the OS theme.
popup.js         Capture, quick picks, the Upcoming list.
nlp.js           Natural-language date extraction and the shared formatters.
store.js         The one place reminders are read, written, and wired to alarms.
background.js    Service worker: alarms, notifications, badge, restart recovery.
fonts/           Instrument Sans and JetBrains Mono, latin subsets, bundled so
                 the popup paints with no network round trip.
icons/           Toolbar and notification icons.
design/          The design canvas the UI was built from. Not part of the
                 extension; safe to delete before packaging.
```

Data lives in `chrome.storage.local` on your machine. Nothing is sent anywhere,
and the extension requests no host permissions, so it cannot read any page.
