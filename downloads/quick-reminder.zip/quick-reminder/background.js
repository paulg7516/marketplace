import { getAll, remove, snooze, schedule, markFired, idFromAlarm, alarmName, SNOOZE_MS, ERROR_KEY } from './store.js';

const SUMMARY_ID = 'qr-summary';
const SUMMARY_THRESHOLD = 3;
const ICON = 'icons/icon128.png';

// chrome.notifications.create reports failure through chrome.runtime.lastError
// in its callback - it does not reject - so a try/catch around the promise form
// sees nothing. This is the only way to find out whether anything was shown.
function createNotification(id, options) {
  return new Promise((resolve) => {
    try {
      chrome.notifications.create(id, options, (createdId) => {
        const err = chrome.runtime.lastError;
        resolve({ id: createdId || null, error: err ? err.message : null });
      });
    } catch (e) {
      resolve({ id: null, error: String((e && e.message) || e) });
    }
  });
}

// Remember the last failure so the popup can show the real reason instead of
// leaving the user to wonder why nothing happened.
async function recordOutcome(result, attempted) {
  if (result.error || !result.id) {
    console.error('Quick Reminder: notification could not be shown.', result.error);
    await chrome.storage.local.set({
      [ERROR_KEY]: { message: result.error || 'Chrome reported no notification id', at: Date.now() }
    });
  } else if (attempted) {
    await chrome.storage.local.remove(ERROR_KEY);
  }
}

async function notify(rem) {
  const base = {
    type: 'basic',
    iconUrl: chrome.runtime.getURL(ICON),
    title: 'Quick Reminder',
    message: rem.text,
    priority: 2
  };

  // macOS hands notifications to the system centre, which rejects buttons and
  // requireInteraction. Try the rich form, then fall back to a plain one.
  let result = await createNotification(alarmName(rem.id), {
    ...base,
    requireInteraction: true,
    buttons: [{ title: 'Done' }, { title: 'Snooze 10 min' }]
  });

  if (result.error || !result.id) {
    console.warn('Quick Reminder: rich notification refused, retrying plain.', result.error);
    result = await createNotification(alarmName(rem.id), base);
  }

  await recordOutcome(result, true);
  // Marked fired even when the notification failed. Leaving it unfired would
  // have it rescheduled on the next storage change, and round it would go.
  await markFired(rem.id);
  return result;
}

// Alarms are derived from storage, never the other way round. Anything in
// storage gets an alarm; any alarm without a reminder behind it is dropped.
async function reconcile() {
  const items = await getAll();
  const now = Date.now();
  const existing = (await chrome.alarms.getAll()).filter((a) => idFromAlarm(a.name));
  const byName = new Map(existing.map((a) => [a.name, a]));
  const wanted = new Set();

  for (const rem of items) {
    if (rem.firedAt) continue;   // delivered already; it is waiting on the user
    const name = alarmName(rem.id);
    wanted.add(name);
    const cur = byName.get(name);
    if (!cur || Math.abs(cur.scheduledTime - rem.due) > 1000) {
      await chrome.alarms.create(name, { when: Math.max(rem.due, now + 1000) });
    }
  }

  for (const name of byName.keys()) {
    if (!wanted.has(name)) await chrome.alarms.clear(name);
  }
}

async function openPopup() {
  // Available from Chrome 127, and only while a browser window has focus.
  try {
    await chrome.action.openPopup();
  } catch (e) {
    // Nothing sensible to fall back to; the badge still shows what is pending.
  }
}

// The badge counts only what is waiting on a decision - reminders that have
// already fired and not been cleared. Something scheduled for next Tuesday is
// precisely what you handed over so you could stop thinking about it; putting a
// number on it hands the job straight back.
async function refreshBadge(list) {
  const items = list || (await getAll());
  const waiting = items.filter((r) => r.firedAt).length;
  await chrome.action.setBadgeText({ text: waiting ? String(waiting) : '' });
  await chrome.action.setBadgeBackgroundColor({ color: '#b54708' });
  if (chrome.action.setBadgeTextColor) {
    await chrome.action.setBadgeTextColor({ color: '#ffffff' });
  }
}

// Rebuild every alarm from storage, and deal with anything that came due while
// the browser was closed. Alarms do not reliably survive a browser restart, so
// this runs on both startup and install/update.
async function resync() {
  const list = await getAll();
  const now = Date.now();

  await chrome.alarms.clearAll();

  const overdue = [];
  for (const rem of list) {
    if (rem.firedAt) continue;
    if (rem.due <= now) overdue.push(rem);
    else await schedule(rem);
  }

  if (overdue.length > SUMMARY_THRESHOLD) {
    // Firing a dozen notifications at once after a long weekend is noise.
    let summary = await createNotification(SUMMARY_ID, {
      type: 'basic',
      iconUrl: chrome.runtime.getURL(ICON),
      title: `${overdue.length} reminders are waiting`,
      message: 'Open Quick Reminder to see them.',
      priority: 2,
      requireInteraction: true
    });
    if (summary.error || !summary.id) {
      summary = await createNotification(SUMMARY_ID, {
        type: 'basic',
        iconUrl: chrome.runtime.getURL(ICON),
        title: `${overdue.length} reminders are waiting`,
        message: 'Open Quick Reminder to see them.',
        priority: 2
      });
    }
    await recordOutcome(summary, true);
    await markFired(overdue.map((r) => r.id));
  } else {
    for (const rem of overdue) await notify(rem);
  }

  await refreshBadge();
}

chrome.runtime.onStartup.addListener(resync);
chrome.runtime.onInstalled.addListener(resync);

chrome.alarms.onAlarm.addListener(async (alarm) => {
  const id = idFromAlarm(alarm.name);
  if (!id) return;
  const rem = (await getAll()).find((r) => r.id === id);
  if (rem) await notify(rem);
});

chrome.notifications.onButtonClicked.addListener(async (notifId, index) => {
  const id = idFromAlarm(notifId);
  if (!id) return;
  await chrome.notifications.clear(notifId);
  if (index === 0) {
    await remove(id);
  } else {
    await snooze(id, SNOOZE_MS);
  }
});

chrome.notifications.onClicked.addListener(async (notifId) => {
  if (!idFromAlarm(notifId) && notifId !== SUMMARY_ID) return;
  await chrome.notifications.clear(notifId);
  await openPopup();
});

// A dismissed notification is not a completed reminder - it stays pending.

chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== 'local' || !changes.reminders) return;
  refreshBadge(changes.reminders.newValue || []);
  // The write may have come from a popup that has since been destroyed, so
  // this is where a newly saved reminder reliably gets its alarm.
  reconcile();
});
