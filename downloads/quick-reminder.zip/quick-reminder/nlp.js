// Natural-language date extraction plus the shared date formatters.
//
// parseWhen() pulls a time phrase out of a sentence and returns both the
// resolved timestamp and the note with that phrase removed, so "call Bob
// tomorrow 9am" becomes "call Bob" scheduled for 09:00 tomorrow.

const WEEKDAYS = {
  sun: 0, sunday: 0, mon: 1, monday: 1, tue: 2, tues: 2, tuesday: 2,
  wed: 3, weds: 3, wednesday: 3, thu: 4, thur: 4, thurs: 4, thursday: 4,
  fri: 5, friday: 5, sat: 6, saturday: 6
};

const MONTHS = ['jan', 'feb', 'mar', 'apr', 'may', 'jun', 'jul', 'aug', 'sep', 'oct', 'nov', 'dec'];

const DAY_NAMES = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
const MONTH_NAMES = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

export function dayAt(base, offset, hour, minute) {
  const d = new Date(base);
  d.setDate(d.getDate() + offset);
  d.setHours(hour, minute, 0, 0);
  return d.getTime();
}

export function fmtTime(ms) {
  const d = new Date(ms);
  const h = d.getHours();
  const m = d.getMinutes();
  const ap = h >= 12 ? 'PM' : 'AM';
  const hh = h % 12 === 0 ? 12 : h % 12;
  return `${hh}:${m < 10 ? '0' + m : m} ${ap}`;
}

export function fmtDay(ms, now) {
  const a = new Date(ms); a.setHours(0, 0, 0, 0);
  const b = new Date(now); b.setHours(0, 0, 0, 0);
  const diff = Math.round((a.getTime() - b.getTime()) / 86400000);
  if (diff === 0) return 'Today';
  if (diff === 1) return 'Tomorrow';
  if (diff === -1) return 'Yesterday';
  if (diff < 0) return 'Overdue';
  const d = new Date(ms);
  // Beyond a week out a weekday name stops being unambiguous, so use the date.
  if (diff > 1 && diff < 7) return DAY_NAMES[d.getDay()];
  return `${MONTH_NAMES[d.getMonth()]} ${d.getDate()}`;
}

// Compact enough for the list's time column: "12m ago", "3h ago", "2d ago".
export function fmtAgo(ms, now) {
  const mins = Math.max(0, Math.round((now - ms) / 60000));
  if (mins < 1) return 'just now';
  if (mins < 60) return `${mins}m ago`;
  const hours = Math.round(mins / 60);
  if (hours < 24) return `${hours}h ago`;
  return `${Math.round(hours / 24)}d ago`;
}

export function fmtFull(ms, now) {
  return `${fmtDay(ms, now)}, ${fmtTime(ms)}`;
}

// The quick-pick options offered in the popup, resolved against `now`.
export function quickOptions(now) {
  let later = dayAt(now, 0, 17, 0);
  if (later <= now + 45 * 60000) later = now + 2 * 3600000;

  const mon = new Date(now);
  mon.setDate(mon.getDate() + (((8 - mon.getDay()) % 7) || 7));
  mon.setHours(9, 0, 0, 0);

  return [
    { key: 'm30', label: '30 min', ms: now + 30 * 60000 },
    { key: 'h1', label: '1 hour', ms: now + 3600000 },
    { key: 'later', label: 'Later today', ms: later },
    { key: 'tmr9', label: 'Tomorrow 9am', ms: dayAt(now, 1, 9, 0) },
    { key: 'tmr2', label: 'Tomorrow 2pm', ms: dayAt(now, 1, 14, 0) },
    { key: 'week', label: 'Next week', ms: mon.getTime() }
  ];
}

export function parseWhen(raw, nowMs = Date.now()) {
  if (!raw || !raw.trim()) return null;

  const pad = ' ' + raw + ' ';
  const low = pad.toLowerCase();
  const cuts = [];

  // Matches on the lowercased copy; indices stay aligned with `pad` because
  // toLowerCase does not change length for the characters we match.
  const take = (re) => {
    const m = re.exec(low);
    if (!m) return null;
    cuts.push([m.index, m.index + m[0].length]);
    return m;
  };

  const cleaned = () => {
    let out = pad;
    for (const [s, e] of [...cuts].sort((a, b) => b[0] - a[0])) {
      out = out.slice(0, s) + ' ' + out.slice(e);
    }
    return out
      .replace(/\s+/g, ' ')
      .replace(/\s+([,.;:!?])/g, '$1')
      .replace(/^[\s,.;:-]+|[\s,.;:-]+$/g, '')
      .replace(/\b(on|at|by|this|next|the)\s*$/i, '')
      .trimEnd();
  };

  const matchedPhrase = () =>
    [...cuts]
      .sort((a, b) => a[0] - b[0])
      .map(([s, e]) => pad.slice(s, e).trim())
      .join(' ');

  // "in 30 minutes" / "in an hour" - a pure offset, nothing else to resolve.
  const rel = take(/\bin (a|an|\d{1,3}) ?(minutes|minute|mins|min|hours|hour|hrs|hr|days|day|weeks|week)\b/);
  if (rel) {
    const n = (rel[1] === 'a' || rel[1] === 'an') ? 1 : parseInt(rel[1], 10);
    const unit = { m: 60000, h: 3600000, d: 86400000, w: 604800000 }[rel[2][0]];
    return { ms: nowMs + n * unit, text: cleaned(), phrase: matchedPhrase() };
  }

  // Clock time. Bare digits only count when preceded by "at" or "@", or when
  // they carry a colon or an am/pm marker - otherwise "call 4 people" parses.
  let hour = null;
  let minute = 0;
  let explicitAmPm = false;

  let t = take(/\b(?:at |@ ?)?(\d{1,2}):(\d{2}) ?(am|pm)?\b/);
  if (!t) t = take(/\b(?:at |@ ?)?(\d{1,2}) ?(am|pm)\b/);
  if (!t) t = take(/\bat (\d{1,2})\b/);

  if (t) {
    if (t[2] && /^\d{2}$/.test(t[2])) {
      hour = parseInt(t[1], 10);
      minute = parseInt(t[2], 10);
      if (t[3]) {
        explicitAmPm = true;
        if (t[3] === 'pm' && hour < 12) hour += 12;
        if (t[3] === 'am' && hour === 12) hour = 0;
      }
    } else if (t[2]) {
      hour = parseInt(t[1], 10);
      explicitAmPm = true;
      if (t[2] === 'pm' && hour < 12) hour += 12;
      if (t[2] === 'am' && hour === 12) hour = 0;
    } else {
      hour = parseInt(t[1], 10);
    }
    if (hour > 23 || minute > 59) return null;
  } else {
    const nm = take(/\b(noon|midnight)\b/);
    if (nm) {
      hour = nm[1] === 'noon' ? 12 : 0;
      explicitAmPm = true;
    }
  }

  // Part of day, which supplies a default hour and can disambiguate a bare one.
  let podHour = null;
  let podOffset = null;
  const pod = take(/\b(morning|afternoon|evening|tonight|night)\b/);
  if (pod) {
    const w = pod[1];
    if (w === 'morning') podHour = 9;
    else if (w === 'afternoon') podHour = 14;
    else if (w === 'evening') podHour = 18;
    else { podHour = 19; podOffset = 0; }
  }

  // Day anchor.
  let offset = null;
  let weekday = null;
  let monthDay = null;

  if (take(/\bday after tomorrow\b/)) offset = 2;
  else if (take(/\b(tomorrow|tmrw|tmw)\b/)) offset = 1;
  else if (take(/\btoday\b/)) offset = 0;
  else if (take(/\bnext week\b/)) offset = ((8 - new Date(nowMs).getDay()) % 7) || 7;
  else {
    const wd = take(/\b(?:next |this |on )?(sunday|sun|monday|mon|tuesday|tues|tue|wednesday|weds|wed|thursday|thurs|thur|thu|friday|fri|saturday|sat)\b/);
    if (wd) {
      weekday = WEEKDAYS[wd[1]];
    } else {
      const md = take(/\b(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]* (\d{1,2})(?:st|nd|rd|th)?\b/);
      if (md) monthDay = [MONTHS.indexOf(md[1]), parseInt(md[2], 10)];
    }
  }

  if (offset === null && weekday === null && monthDay === null && podOffset !== null) {
    offset = podOffset;
  }
  if (hour === null && podHour !== null) {
    hour = podHour;
  } else if (hour !== null && !explicitAmPm && podHour !== null && podHour >= 12 && hour < 12) {
    hour += 12;
  }

  if (offset === null && weekday === null && monthDay === null && hour === null) return null;

  const d = new Date(nowMs);
  if (hour === null) {
    hour = 9;
  } else if (!explicitAmPm && podHour === null && hour >= 1 && hour <= 7) {
    // "at 3" means the afternoon; "at 9" does not.
    hour += 12;
  }

  if (weekday !== null) {
    let delta = (weekday - d.getDay() + 7) % 7;
    if (delta === 0 && dayAt(nowMs, 0, hour, minute) <= nowMs) delta = 7;
    d.setDate(d.getDate() + delta);
    d.setHours(hour, minute, 0, 0);
  } else if (monthDay !== null) {
    d.setMonth(monthDay[0], monthDay[1]);
    d.setHours(hour, minute, 0, 0);
    if (d.getTime() < nowMs) d.setFullYear(d.getFullYear() + 1);
  } else {
    d.setDate(d.getDate() + (offset === null ? 0 : offset));
    d.setHours(hour, minute, 0, 0);
    // A bare time that already passed means tomorrow.
    if (d.getTime() <= nowMs && offset === null) d.setDate(d.getDate() + 1);
  }

  if (d.getTime() <= nowMs - 60000) return null;
  return { ms: d.getTime(), text: cleaned(), phrase: matchedPhrase() };
}
