import { parseWhen, quickOptions, fmtTime, fmtDay, fmtFull, fmtAgo } from './nlp.js';
import { getAll, add, remove, edit as reviseReminder, ERROR_KEY } from './store.js';

const $ = (id) => document.getElementById(id);

const CHECK_SVG = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6.5L9.2 17.3 4 12.1"></path></svg>';
const CROSS_SVG = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><path d="M6 6l12 12M18 6L6 18"></path></svg>';
const CAL_SVG = '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="5" width="18" height="16" rx="2.5"></rect><path d="M3 10h18M8 3v4M16 3v4"></path></svg>';

// Resolved once when the popup opens; it lives for seconds, not hours.
const OPTIONS = quickOptions(Date.now());

const NOTE_MAX_H = 220;

let pick = null;      // { key, ms } - an explicit choice, which beats the parse
let items = [];
let flashTimer = null;
let noteDragged = false;   // once you size it by hand, auto-grow backs off
let editing = null;        // id of the reminder loaded into the field

// Keep the whole note visible without making the popup taller than it needs
// to be. Past NOTE_MAX_H the field scrolls, and the drag handle still works.
function autoGrow() {
  if (noteDragged) return;
  const ta = $('note');
  ta.style.height = 'auto';
  ta.style.height = Math.min(ta.scrollHeight, NOTE_MAX_H) + 'px';
}

/* Capture ------------------------------------------------------------ */

function buildPills() {
  const wrap = $('pills');

  for (const opt of OPTIONS) {
    const b = document.createElement('button');
    b.type = 'button';
    b.className = 'pill';
    b.dataset.key = opt.key;
    b.dataset.on = '0';
    b.textContent = opt.label;
    b.title = fmtFull(opt.ms, Date.now());
    b.addEventListener('click', () => {
      pick = pick && pick.key === opt.key ? null : { key: opt.key, ms: opt.ms };
      $('custom').hidden = true;
      update();
    });
    wrap.appendChild(b);
  }

  const c = document.createElement('button');
  c.type = 'button';
  c.className = 'pill custom-pill';
  c.dataset.key = 'custom';
  c.dataset.on = '0';
  c.innerHTML = CAL_SVG;
  c.appendChild(document.createTextNode('Pick a date'));
  c.addEventListener('click', () => {
    const input = $('custom');
    input.hidden = !input.hidden;
    if (input.hidden) {
      if (pick && pick.key === 'custom') pick = null;
    } else {
      input.focus();
    }
    update();
  });
  wrap.appendChild(c);
}

function toInputValue(ms) {
  const d = new Date(ms - new Date(ms).getTimezoneOffset() * 60000);
  return d.toISOString().slice(0, 16);
}

function beginEdit(rem) {
  editing = rem.id;
  pick = { key: 'custom', ms: rem.due };
  $('note').value = rem.text;
  $('custom').value = toInputValue(rem.due);
  $('custom').hidden = false;
  $('editing').hidden = false;
  noteDragged = false;
  autoGrow();
  update();
  renderList();
  $('note').focus();
  $('note').setSelectionRange($('note').value.length, $('note').value.length);
}

function cancelEdit() {
  editing = null;
  pick = null;
  $('note').value = '';
  $('custom').value = '';
  $('custom').hidden = true;
  $('editing').hidden = true;
  autoGrow();
  update();
  renderList();
  $('note').focus();
}

function resolve() {
  const now = Date.now();
  const raw = $('note').value;
  const parsed = parseWhen(raw, now);
  const detected = pick ? null : parsed;
  const ms = pick ? pick.ms : (parsed ? parsed.ms : null);
  // The typed time phrase is stripped from the note either way: if you wrote
  // "call Bob tomorrow 9am" and then picked a pill, "tomorrow 9am" was still
  // meant as a time, not as part of the note.
  const text = parsed && parsed.text ? parsed.text : raw.trim();
  return { now, raw, ms, text, detected };
}

function update() {
  const { now, raw, ms, detected } = resolve();
  const hasText = raw.trim().length > 0;
  const ready = ms !== null && hasText;

  const line = $('detect');
  if (detected) {
    line.hidden = false;
    $('detectTime').textContent = fmtFull(detected.ms, now);
    $('detectSrc').textContent = detected.phrase ? `from “${detected.phrase}”` : '';
  } else {
    line.hidden = true;
  }

  for (const b of $('pills').children) {
    b.dataset.on = pick && pick.key === b.dataset.key ? '1' : '0';
  }

  const go = $('go');
  go.disabled = !ready;
  $('goLabel').textContent = ready
    ? (editing ? 'Update reminder' : 'Set reminder')
    : (hasText ? 'Pick a time' : 'Type a note');
  $('goTime').textContent = ready ? fmtFull(ms, now) : '';
}

function flash(message) {
  const el = $('flash');
  el.textContent = message;
  el.classList.add('on');
  clearTimeout(flashTimer);
  flashTimer = setTimeout(() => el.classList.remove('on'), 2600);
}

async function save() {
  const { now, raw, ms, text } = resolve();
  if (ms === null || !raw.trim()) return;

  if (editing) {
    await reviseReminder(editing, text || raw.trim(), ms);
    flash('updated · ' + fmtFull(ms, now));
  } else {
    await add(text || raw.trim(), ms);
    flash('saved · ' + fmtFull(ms, now));
  }

  editing = null;
  $('note').value = '';
  autoGrow();
  $('custom').value = '';
  $('custom').hidden = true;
  $('editing').hidden = true;
  pick = null;

  await load();
  update();
  $('note').focus();
}

/* Upcoming ----------------------------------------------------------- */

function makeRow(rem, now, state) {
  const row = document.createElement('div');
  row.className = `row ${state}`;
  if (editing === rem.id) row.classList.add('is-editing');
  row.tabIndex = 0;
  row.setAttribute('role', 'button');
  row.title = 'Open to read or change';

  const dot = document.createElement('span');
  dot.className = 'dot';

  const text = document.createElement('span');
  text.className = 'row-text';
  text.textContent = rem.text;
  text.title = rem.text;

  const right = document.createElement('span');
  right.className = 'row-right';

  const time = document.createElement('span');
  time.className = 'row-time';
  // One that already went off is better described by how long it has been
  // sitting there than by the clock time it was set for.
  time.textContent = state === 'waiting' ? fmtAgo(rem.firedAt || rem.due, now) : fmtTime(rem.due);
  time.title = fmtFull(rem.due, now);

  const acts = document.createElement('span');
  acts.className = 'row-acts';

  const done = document.createElement('button');
  done.type = 'button';
  done.className = 'ic';
  done.title = 'Done';
  done.setAttribute('aria-label', `Done: ${rem.text}`);
  done.innerHTML = CHECK_SVG;
  done.addEventListener('click', (e) => {
    e.stopPropagation();
    clear(rem.id, 'done');
  });

  const del = document.createElement('button');
  del.type = 'button';
  del.className = 'ic del';
  del.title = 'Delete';
  del.setAttribute('aria-label', `Delete: ${rem.text}`);
  del.innerHTML = CROSS_SVG;
  del.addEventListener('click', (e) => {
    e.stopPropagation();
    clear(rem.id, 'removed');
  });

  row.addEventListener('click', () => beginEdit(rem));
  row.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' || e.key === ' ') {
      e.preventDefault();
      beginEdit(rem);
    }
  });

  acts.append(done, del);
  right.append(time, acts);
  row.append(dot, text, right);
  return row;
}

function renderList() {
  const now = Date.now();
  const rows = $('rows');
  rows.textContent = '';
  $('count').textContent = items.length ? String(items.length) : '';

  if (!items.length) {
    const empty = document.createElement('div');
    empty.className = 'empty';
    const title = document.createElement('div');
    title.className = 'empty-title';
    title.textContent = 'Nothing scheduled';
    const sub = document.createElement('div');
    sub.className = 'empty-sub';
    sub.textContent = 'It is all out of your head.';
    empty.append(title, sub);
    rows.appendChild(empty);
    return;
  }

  const header = (label) => {
    const h = document.createElement('div');
    h.className = 'day';
    h.textContent = label;
    rows.appendChild(h);
  };

  // Anything that has already gone off is waiting on a decision, not upcoming,
  // so it gets its own group at the top rather than sitting in a day bucket.
  const waiting = items.filter((r) => r.firedAt);
  const upcoming = items.filter((r) => !r.firedAt);

  if (waiting.length) {
    header('Waiting on you');
    for (const rem of waiting) rows.appendChild(makeRow(rem, now, 'waiting'));
  }

  // The rest are grouped by day, so each row only has to carry a time.
  let lastDay = null;
  for (const rem of upcoming) {
    const day = fmtDay(rem.due, now);
    if (day !== lastDay) {
      header(day);
      lastDay = day;
    }
    rows.appendChild(makeRow(rem, now, rem.due - now < 12 * 3600000 ? 'soon' : 'later'));
  }
}

async function clear(id, word) {
  if (editing === id) cancelEdit();
  await remove(id);
  flash(word);
  await load();
}

async function load() {
  items = await getAll();
  renderList();
}

/* Wiring ------------------------------------------------------------- */

$('note').addEventListener('input', () => {
  autoGrow();
  update();
});

// The native resize grip sits in the bottom-right corner; a pointer landing
// there is the one thing other than typing that changes the height.
$('note').addEventListener('pointerdown', (e) => {
  const r = $('note').getBoundingClientRect();
  if (e.clientX >= r.right - 18 && e.clientY >= r.bottom - 18) noteDragged = true;
});

$('note').addEventListener('keydown', (e) => {
  if (e.key === 'Enter' && !e.shiftKey) {
    e.preventDefault();
    save();
  }
});

document.addEventListener('keydown', (e) => {
  if (e.key !== 'Escape') return;
  // Back out of an edit first; a second Escape closes the popup.
  if (editing) cancelEdit();
  else window.close();
});

$('cancelEdit').addEventListener('click', cancelEdit);

$('go').addEventListener('click', save);

$('custom').addEventListener('input', () => {
  const v = $('custom').value;
  const ms = v ? new Date(v).getTime() : NaN;
  pick = Number.isNaN(ms) ? null : { key: 'custom', ms };
  update();
});

$('custom').min = toInputValue(Date.now());

// Show the real binding, whatever it currently is, and make the hint the way
// to change it - a shortcut that silently does nothing is worse than none.
$('kbd').addEventListener('click', () => {
  chrome.tabs.create({ url: 'chrome://extensions/shortcuts' });
  window.close();
});

// "\u21e7\u2318E" on macOS, "Ctrl+Shift+E" elsewhere. Split either into one cap
// per key, keeping word keys like Space or Ctrl whole.
function keyCaps(shortcut) {
  if (shortcut.includes('+')) {
    return shortcut.split('+').map((s) => s.trim()).filter(Boolean);
  }
  return shortcut.match(/[A-Za-z0-9]+|[^A-Za-z0-9]/gu) || [shortcut];
}

chrome.commands.getAll().then((cmds) => {
  const cmd = cmds.find((x) => x.name === '_execute_action');
  const el = $('kbd');
  el.textContent = '';

  if (cmd && cmd.shortcut) {
    el.classList.remove('kbd-set');
    for (const key of keyCaps(cmd.shortcut)) {
      const cap = document.createElement('span');
      cap.className = 'cap';
      cap.textContent = key;
      el.appendChild(cap);
    }
    el.title = `${cmd.shortcut} opens Quick Reminder. Click to change it.`;
  } else {
    el.classList.add('kbd-set');
    el.textContent = 'Set shortcut';
    el.title = 'No shortcut assigned. Click to set one.';
  }
  el.hidden = false;
});

// A reminder that can never fire is worse than no reminder. Surface both the
// blocked-permission case and whatever Chrome said the last time a reminder
// actually failed, rather than letting either fail silently.
async function checkHealth() {
  const level = await new Promise((r) => chrome.notifications.getPermissionLevel(r));
  const bag = await chrome.storage.local.get(ERROR_KEY);
  const failure = bag[ERROR_KEY];

  let message = null;
  if (level !== 'granted') {
    message = 'Chrome is blocking notifications, so reminders will not appear.';
  } else if (failure) {
    message = `A reminder could not be shown: ${failure.message}`;
  }
  if (!message) return;

  $('warnText').textContent = message;
  $('warn').title = 'Open Chrome notification settings';
  $('warn').hidden = false;
}

$('warn').addEventListener('click', () => {
  chrome.tabs.create({ url: 'chrome://settings/content/notifications' });
  window.close();
});

checkHealth();

buildPills();
autoGrow();
update();
load();
$('note').focus();
