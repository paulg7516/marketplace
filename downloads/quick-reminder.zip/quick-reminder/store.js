// The one place reminders are read, written, and wired to alarms.
// Imported by both the popup and the service worker.

export const KEY = 'reminders';
export const ERROR_KEY = 'lastNotifyError';
export const ALARM_PREFIX = 'qr:';
export const SNOOZE_MS = 10 * 60 * 1000;

export function alarmName(id) {
  return ALARM_PREFIX + id;
}

export function idFromAlarm(name) {
  return name.startsWith(ALARM_PREFIX) ? name.slice(ALARM_PREFIX.length) : null;
}

export async function getAll() {
  const bag = await chrome.storage.local.get(KEY);
  const list = bag[KEY];
  return Array.isArray(list) ? list : [];
}

export async function saveAll(list) {
  list.sort((a, b) => a.due - b.due);
  await chrome.storage.local.set({ [KEY]: list });
}

export async function schedule(rem) {
  // Chrome clamps alarms to a 30 second minimum; a `when` in the past fires
  // on the next service-worker wake.
  await chrome.alarms.create(alarmName(rem.id), { when: rem.due });
}

export async function cancel(id) {
  await chrome.alarms.clear(alarmName(id));
}

export async function add(text, due) {
  const list = await getAll();
  const rem = { id: crypto.randomUUID(), text, due, created: Date.now() };
  list.push(rem);
  // Storage first, always. A popup can be torn down the instant it loses
  // focus, so scheduling here is only a fast path - background.js reconciles
  // alarms from storage and is what actually guarantees the alarm exists.
  await saveAll(list);
  await schedule(rem);
  return rem;
}

export async function remove(id) {
  const list = await getAll();
  await saveAll(list.filter((r) => r.id !== id));
  await cancel(id);
}

export async function snooze(id, ms = SNOOZE_MS) {
  const list = await getAll();
  const rem = list.find((r) => r.id === id);
  if (!rem) return null;
  rem.due = Date.now() + ms;
  delete rem.firedAt;          // snoozing puts it back in the queue
  await saveAll(list);
  await schedule(rem);
  return rem;
}

export async function edit(id, text, due) {
  const list = await getAll();
  const rem = list.find((r) => r.id === id);
  if (!rem) return null;
  rem.text = text;
  rem.due = due;
  // Pushing it into the future re-arms it. Fixing a typo on something already
  // waiting leaves it waiting rather than firing again a second later.
  if (due > Date.now()) delete rem.firedAt;
  await saveAll(list);
  await schedule(rem);
  return rem;
}

// A reminder fires once. After that it waits for Done rather than being
// rescheduled, which is what stopped old reminders going off again every time
// a new one was saved.
export async function markFired(ids, at = Date.now()) {
  const wanted = new Set(Array.isArray(ids) ? ids : [ids]);
  const list = await getAll();
  let changed = false;
  for (const rem of list) {
    if (wanted.has(rem.id) && !rem.firedAt) {
      rem.firedAt = at;
      changed = true;
    }
  }
  if (changed) await saveAll(list);
  return changed;
}
